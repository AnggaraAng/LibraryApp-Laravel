# LibraryApp-laravel

Project Ini adalah tugas akhir untuk mata kuliah Pemrograman Lanjut dengan dosen pembimbing Radius Tanone.

Prject ini bersifat kelompok yang beranggotakan :

ANGGI ANGGARA 				(672017287)
BRIAN FIRGIANTO 			(672017005)
ADRIANSA WAHYU PRAMUDITA	(672017252)
YULIA FRANSICA WIJAYA		(672017057)

Terima Kasih ..
